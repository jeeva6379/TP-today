module.exports = {
    content: [
      ...,
      'node_modules/flowbite-react/**/*.{js,jsx,ts,tsx}'
    ],
    plugins: [..., require('flowbite/plugin')],
    ...
  };
  